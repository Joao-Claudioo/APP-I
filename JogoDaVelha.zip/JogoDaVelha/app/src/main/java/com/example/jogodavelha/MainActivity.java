package com.example.jogodavelha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnComo, btnJogar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnComo = findViewById(R.id.btnComo);
        btnJogar = findViewById(R.id.btnJogar);

        btnComo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirComo();

            }
        });
        btnJogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirGame();

            }
        });
    }

    private void abrirComo() {
        Intent janela = new Intent(this, ComoJogar.class);
        startActivity(janela);
    }
    private void abrirGame() {
        Intent janelag = new Intent(this, Jogo.class);
        startActivity(janelag);
    }
}